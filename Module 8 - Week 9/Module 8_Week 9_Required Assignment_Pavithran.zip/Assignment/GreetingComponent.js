//3. Create and Render Functional Components (5 Marks)
export default function GreetingComponent(props) {
    return <h2>Hi {props.fName} Welcome to the React World! </h2>;
}